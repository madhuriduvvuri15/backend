
#Commands to run


$ python main.py

#This command will compile and run main.py as well as crd.py (as crd file is imported in main)

